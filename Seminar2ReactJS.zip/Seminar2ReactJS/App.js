//import logo from './logo.svg';
import './App.css';
import WorkWithComments from './components/WorkWithComments';

function App() {
  return (
    <div className="App">
      <WorkWithComments />
    </div>
  );
}

export default App;
