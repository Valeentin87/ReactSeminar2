// Задание: Список комментариев с удалением.

// Цель: Комбинирование useState, рендеринга списков и обработки событий для создания интерактивного интерфейса.

// Задача:
// Создать компонент CommentsList, который отображает список комментариев. Каждый комментарий должен иметь кнопку для его удаления. При нажатии на кнопку комментарий должен удаляться из списка.

import { useState, useEffect } from "react";


const WorkWithComments = () => {

    const [comments, setComments] = useState([
        { id: 1, text: "Это первый комментарий" },
        { id: 2, text: "Это второй комментарий" },
        { id: 3, text: "Это третий комментарий" }
        ]);

      
    function deleteComment (event)  {
        const currentEl = event.target
        const textComment = currentEl.previousElementSibling.textContent;
        let delCom = currentEl.parentNode.firstChild;
        delCom.remove();
        currentEl.remove();
        let newComments = [];
        let delIndex;
        for(let comment of comments){
            if ((comment.text).trim() === textComment.trim()) {
                delIndex = Number(comment.id);
                comments.splice(delIndex - 1,1);
                newComments = comments;
                setComments(newComments);
                console.log(comments);
                return;
            }
        }
    }
        
    return (
        <ul className="listComments">
            {comments.map((item) => 
            <div>    
            <li key={item.id}> {item.text}</li>
            <button onClick={deleteComment}>Удалить</button>
            </div>    
            )}
        </ul>

    )
}

export default WorkWithComments;